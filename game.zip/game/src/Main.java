public class Main {

    public static void main(String[] args) {
        Play game = new Play();
        game.begin();
    }
}