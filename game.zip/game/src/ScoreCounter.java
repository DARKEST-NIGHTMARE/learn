import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.lang.String;

// 1. store / load high score in file
// 2. Event Management Ap
//   2.1 Add/Delete Event (title, data, description)
//   2.2 View All Events
//   2.3 Store them in file
//   2.4 Home / Start Screen - show upcoming events
//  3. Tic-Tac-Toe game - 2 players, AI

class ScoreCounter {

    private int score = 0;


    private int highScore = 0;

    private int gameScore = 0;



    public void correctAnswer() {
        gameScore += 1;
    }

    public void wrongAnwser() {
        gameScore += 0;
    }

    public boolean isNewHighScore() {
        return gameScore > highScore;
    }

    public int getGameScore() {
        return gameScore;
    }

    public void setHighScore() throws IOException {
//        try{
//            FileReader file1 = new FileReader("highscore.txt");
//            int i;
//            while((i=file1.read())!=-1){
//            highScore = Integer.parseInt(String.valueOf(i));
//            }
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }


        highScore = Math.max(highScore, gameScore);
        try{FileWriter file = new FileWriter("highscore.txt");
        file.write(highScore);}
        catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}